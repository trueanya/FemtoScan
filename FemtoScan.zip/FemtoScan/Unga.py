import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def objective(x, a, b):
	return a * x + b

def cut_line(df):
    df.rename(columns={0: 'x', 1: 'y'}, inplace=True)
    df = df.assign(diffr = df.y.shift(0) - df.y.shift(-1))
    length = df.shape[0]
    df1 = df.iloc[(length//4):(length - length//4) ]
    std = df1.diffr.std()
    df = df[ (df['y'] > 0) & (abs(df['diffr']) >= std)]
    return df

df = pd.read_excel('clean.xlsx', index_col=None, header=None)
df = df.iloc[3:]
df = df.astype('float')
df = cut_line(df)
df.plot(x=0, y=1)
#plt.show()
popt, _ = curve_fit(objective, df['x'], df['y'])
a, b = popt
k = 1/a
cant = 0.03
kk = k*cant

df2 = pd.read_excel('eryth.xlsx', index_col=None, header=None)
df2 = df2.iloc[3:]
df2 = df2.astype('float')
df2 = cut_line(df2)
df2['x'] = df2['x'].transform(lambda x: x*x)
df2['y'] = df2['y'].transform(lambda x: x*kk)
df2.plot(x=0, y=1)
#plt.show()
popt2, _ = curve_fit(objective, df2['x'], df2['y'])
a2, b2 = popt2
puasson = 0.33
r = 40e-08
E = ((3/4) * a2/(r**0.5))*(1 - puasson**2)
print(E)


