# надо чтобы была проверка если 3 слова найдены в этой иттерации, то 2 не надо
from xml.dom import minidom
import re
import xml.etree.ElementTree as ET
from googletrans import Translator
#from translate import Translator
translator = Translator()
#print (translation)
#result = translator.translate('Найти параметры для персистентной модели', src='ru', dest='en')
#print("result=", result.text)
mydoc = minidom.parse('work.xml')
tree = ET.ElementTree(file='work.xml')
doc = ET.parse('work.xml')
root = doc.getroot()
data = []
datastr = ''
# добываем в список все Text string между тегов
p = 0
for (ev, el) in ET.iterparse('work.xml'):
    for i in el:
        if str(i.text) != 'None':
            print("first", i.text)
            if p != 0:
                if datastr.find(i.text) != -1 or str(i.text).find(datastr) != -1: # проверяем есть ли такая или часть такой строки в листе
                        print("p=", p)
                        n = 0
                        print("data=", datastr)
                        print("i=", i.text)
                        for elem in data: # ищем какой конкретно элемент совпадает
                            elemstr = ''.join(elem)
                            print("elem=",elem," ",elemstr)
                            if elemstr.find(str(i.text)) != -1 or str(i.text).find(elemstr) != -1:
                                #print("tg")
                                if len(str(i.text)) > len(elemstr): #проверяем, кто из них длиннее, того ставим раньше
                                    data.insert((data.index(elem)-1), i.text)
                                    #print("готов инсерт")
                                    #print("len1=",len(str(i.text)))
                                    #print("len1=", len(elemstr))
                                    break
                                else:
                                    data.append(i.text.replace('\n', '').replace('\t', '').replace('  ', ''))
                else:
                    data.append(i.text.replace('\n', '').replace('\t', '').replace('  ', ''))
                    #print("Готово")
                    break
            else:
                data.append(i.text.replace('\n', '').replace('\t', '').replace('  ', ''))
                #print("Готово")
        p += 1
    datastr = ' '.join(data)

#print(data)
la = []
# функция для создания нового перечня слов(чтобы избежать пересечений), после поиска одного из сета фраз( из 3 слов или из 2 слов)
def is_identical(dict_b, list_la):
    new = " "
    for value in dict_b.values():
        if value not in list_la:
            new += value
    return new
# Ищем все фразы внутри атрибутов и тегов только на русском
for elem in tree.iter():
    b = elem.attrib
    items = mydoc.getElementsByTagName(elem)
    # print(items)
    for element in items:
        print("Data = ", element.firstChild.data)
    a = str(b)
    result0 = re.compile(r'[а-яА-Я]+\s[а-яА-Я]+\s[а-яА-Я]+', re.UNICODE)
    result1 = re.compile((r'[а-яА-Я]+\s[а-яА-Я]+'), re.UNICODE)
    result2 = re.compile(r'[а-яА-ЯёЁ]+', re.UNICODE)
    Temp = re.findall(result0, a)
    Attention = " "
    if len(Temp) != 0:  # Для 3 слов
        Attention = ' '.join(Temp)
        # print("Attention =",Attention)
        la.append(Temp[0])
    New = is_identical(b, la)
    newN = str(New)
    Temp1 = re.findall(result1, a)
    Temp1Str = ' '.join(Temp1)
    # print("Temp1Str=",Temp1Str)
    if len(Temp1) != 0:  # Для 2 слов
        # print("Temp1=",Temp1Str)
        if (Attention.find(Temp1Str)) == -1:
            la.append(Temp1[0])
    # print("la=",la)
    New = is_identical(b, la)
    # print("New=",New)
    newN = str(New)
    Temp2 = re.findall(result2, newN)
    # print("Temp2=",Temp2)
    Temp2Str = ' '.join(Temp2)
    # print("Temp2Str=",Temp2Str)
    if len(Temp2) != 0:
        if ((Attention.find(Temp2Str)) & Temp1Str.find(Temp2Str)) == -1:
            la.append(Temp2[0])
# надо чтобы одно слово не было одним словом из трио или пары
spisok = []
k = 0
for item in la:
    if item == []:
        pass
    else:
        spisok.insert(k, item)
        k += 1
m = k
for item in data:
    if item == '' or None:
        pass
    else:
        spisok.insert(m, item)
        m += 1
print(spisok)

#print("Final=", *spisok, sep='\n')
# Переводим
from deep_translator import GoogleTranslator

# есть строки на половину совпадающие и тогда они обрабатываются и переводятся 2 раза
output_file = open("output_file.txt", 'w+')
Processed =''
Alltogether = ''
import io
with io.open("work.txt", encoding='utf-8') as file:
    while True:
        line = file.readline()
        if not line:
            break

        for i in spisok:
            if line.find(str(i)) != -1:
                print(line)
                Processed += line
                old = str(i)
                translated = GoogleTranslator(source='auto', target='zh-tw').translate(i)
                new = str(translated)
                new_data = line.replace(old,new)
                Alltogether += new_data
                break

        if Processed.find(line) == -1:
                 Alltogether += line


print('Here')
with open("res.txt",'w', encoding='utf-8') as f:
  f.write(Alltogether)
print("end of work")


import xml.etree.ElementTree as ET
from xml.dom import minidom
import io
from deep_translator import GoogleTranslator

def hascyr(s):
    lower = set('абвгдеёжзийклмнопрстуфхцчшщъыьэюя')
    return lower.intersection(s.lower()) != set()


# вот так получаем фарзы между тегов
data = []
for (ev, el) in ET.iterparse('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml'):
    for i in el:
        if hascyr(str(i.text)):
            data.append('>' + str(i.text) + '<')

print(data)
translated_data = []
for i in data:
    translated_data.append((i, GoogleTranslator(source='ru', target='en').translate(i)))
#print(translated_data)
translated_data_dict = {}
for i in translated_data:
    new =  dict(i)
    print(new, type(new))
    translated_data_dict = translated_data_dict.update( dict(zip(i)) )
print(translated_data_dict)






datainside = []
# вот так получаем фразу внутри функций (в кавычках)
mydoc = minidom.parse('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml')
tree = ET.ElementTree(file='C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml')
for elem in tree.iter():
    b = elem.attrib
    if b: datainside.append('"' + str(b['name']) + '"')
#print(datainside)


'''
output_file = open("output_file.txt", 'w+')
with io.open('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml', encoding='utf-8') as file:
    while True:
        line = file.readline()
        if not line:
            break
        elif hascyr(line):
            #print(line)
'''



import xml.etree.ElementTree as ET
from xml.dom import minidom
import io
from deep_translator import GoogleTranslator


def hascyr(s: str):  # функция,проверяющая наличие кириллицы в строке
    lower = set('абвгдеёжзийклмнопрстуфхцчшщъыьэюя')
    return lower.intersection(s.lower()) != set()


# вот так получаем фарзы между тегов
data = []
for (ev, el) in ET.iterparse('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml'):
    for i in el:
        if hascyr(str(i.text)):
            data.append('>' + str(i.text) + '<')

print(data)

translated_data = []
for i in data:
    # в список добавляем кортеж (фраза, перевод)
    translated_data.append((i, GoogleTranslator(source='ru', target='en').translate(i)) )

translated_data_dict = {}

def conversion(tup, dict):
    for x, y in tup:
        dict.setdefault(x, []).append(y)
    return dict


conversion(translated_data, translated_data_dict)
print(translated_data_dict)

datainside = []
# вот так получаем фразу внутри функций (в кавычках)
mydoc = minidom.parse('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml')
tree = ET.ElementTree(file='C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml')
for elem in tree.iter():
    b = elem.attrib
    if b: datainside.append('"' + str(b['name']) + '"')

translated_data_inside = []

for i in datainside:
    #в список добавляем кортеж (фраза, перевод)
    translated_data_inside.append((i, GoogleTranslator(source='ru', target='en').translate(i)) )

translated_data_dict_inside = {}
conversion(translated_data_inside, translated_data_dict_inside)
print(translated_data_dict_inside)

all = translated_data_dict_inside | translated_data_dict

print(all)

'''
#output_file = open("C:/Users/atrukhova/PycharmProjects/FemtoScan/.xml", 'w+')
with io.open("C:/Users/atrukhova/PycharmProjects/FemtoScan/.xml", 'w+') as filenew:
    with io.open('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml', encoding='utf-8') as file:
        while True:
            line = file.readline()
            if not line:
                break
            elif not hascyr(line):
                filenew.write(line)
            elif hascyr(line):
                print(line)

            # надо вернуться к моменту как мы вытаскиваем предложения и понять как заменять их, разделить на 2 вида
            #как и при вытаскивании
'''
