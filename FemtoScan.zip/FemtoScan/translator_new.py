import xml.etree.ElementTree as ET
from xml.dom import minidom
import io
from deep_translator import GoogleTranslator


def hascyr(s: str):  # функция,проверяющая наличие кириллицы в строке
    lower = set('абвгдеёжзийклмнопрстуфхцчшщъыьэюя')
    return lower.intersection(s.lower()) != set()


# вот так получаем фарзы между тегов
data = []
for (ev, el) in ET.iterparse('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml'):
    for i in el:
        if hascyr(str(i.text)):
            data.append('>' + str(i.text) + '<')

translated_data = []
for i in data:
    # в список добавляем кортеж (фраза, перевод)
    translated_data.append((i, GoogleTranslator(source='ru', target='en').translate(i)) )

translated_data_dict = {}

def conversion(tup, dict):
    for x, y in tup:
        dict.setdefault(x, []).append(y)
    return dict


conversion(translated_data, translated_data_dict)
#print(translated_data_dict)

datainside = []
# вот так получаем фразу внутри функций (в кавычках)
#здесь надо поменять адрес в стр 38 и стр 39 на адерс переводимого документа
mydoc = minidom.parse('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml')
tree = ET.ElementTree(file='C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml')
for elem in tree.iter():
    b = elem.attrib
    if b: datainside.append('"' + str(b['name']) + '"')

translated_data_inside = []

for i in datainside:
    #в список добавляем кортеж (фраза, перевод)
    translated_data_inside.append((i, GoogleTranslator(source='ru', target='en').translate(i)) )

translated_data_dict_inside = {}
conversion(translated_data_inside, translated_data_dict_inside)
#print(translated_data_dict_inside)

all = translated_data_dict_inside | translated_data_dict
# в output_file Пишем адрес папки, в которой хотите создать новый переведенный файл
# в io.open as filenew дублируем адрес для нового файла
# в io.open as file вписываем адрес исходного файла
output_file = open("C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm_translated.xml", 'w+')
with io.open("C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm_translated.xml", 'w+') as filenew:
    with io.open('C:/Users/atrukhova/PycharmProjects/FemtoScan/fsmspm.xml', encoding='utf-8') as file:
        while True:
            line = file.readline()
            if not line:
                break
            elif not hascyr(line):
                filenew.write(line)
            elif hascyr(line):
                for (i, j) in all.items():
                    if line.find(i) != -1:
                        #print(i,str(j[0]))
                        line = line.replace(str(i), str(j[0]))
                        filenew.write(line)

